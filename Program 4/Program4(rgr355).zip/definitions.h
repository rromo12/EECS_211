#ifndef definitions
#define definitions
#define MAX_CMD_LINE_LENGTH 255
#define MAX_TOKENS_ON_A_LINE 10
#endif 